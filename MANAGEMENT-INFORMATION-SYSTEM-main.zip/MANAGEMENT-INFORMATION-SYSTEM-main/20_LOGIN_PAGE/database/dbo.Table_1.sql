﻿CREATE TABLE [dbo].[Table_1]
(
	[Id] INT NOT NULL PRIMARY KEY DEFAULT 1, 
    [username] NCHAR(10) NULL, 
    [password] NCHAR(10) NULL 
)

﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [username] NCHAR(10) NULL, 
    [password] NCHAR(10) NULL
)

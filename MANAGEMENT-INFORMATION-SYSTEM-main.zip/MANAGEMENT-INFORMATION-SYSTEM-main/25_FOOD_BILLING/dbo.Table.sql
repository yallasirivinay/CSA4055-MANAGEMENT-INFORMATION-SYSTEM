﻿CREATE TABLE [dbo].[FOOD]
(
	[Id] INT NULL  , 
    [fooditem] NCHAR(50) NULL, 
    [quantity] INT NULL, 
    [price] FLOAT NULL
)
